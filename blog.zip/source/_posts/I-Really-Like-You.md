---
title: I Really Like You
date: 2017-09-04 17:09:32
tags: 音乐
---

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=30841076&auto=0&height=66"></iframe>

I really wanna stop
明明很想让一切停下
But I just gotta taste for it
却又舍不得不甘心就这样浅尝辄止啊
I feel like I could fly with the ball on the moon
这感觉让我如同漂浮在月球上空 自由飞舞
So honey hold my hand you like making me wait for it
亲爱的 就握紧我手 这一刻我已期待很久
I feel I could die walking up to the room, oh yeah
当走向你房门的时候 我的心跳快得让我难以承受
Late night watching television
我们可以深夜一起窝在沙发看剧依偎
But how we get in this position?
但这么快就到这一步是否合适
It's way too soon, I know this isn't love
也许真的进展太快 还不能把这一切叫作爱
But I need to tell you something
但我真的很想对你说
I really really really really really really like you
我真的 真的 真的 真的好喜欢你
And I want you, do you want me, do you want me, too?
真的好想就这样拥着你占有你 你是否有和我一样的心情
I really really really really really really like you
我是真的 真的 真的 真的好喜欢你
And I want you, do you want me, do you want me, too?
也真的好像就这样将你占据 你是否也会有和我一样的心情
Oh, did I say too much?
噢 我是不是有点多话了
I'm so in my head
但我心里确实是这样想的
When we're out of touch
尤其当我们没在联络的时候
I really really really really really really like you
我才真的明白 我是真的真的很喜欢你
And I want you, do you want me, do you want me, too?
也真的好想得到你拥有你占有你 告诉我你和我也是一样的心情
It's like everything you say is a sweet revelation
你说的每一字句在我听来都像是甜言蜜语的表白
All I wanna do is get into your head
我多想了解你的一切和你此刻内心真实的想法
Yeah we could stay alone, you and me, and this temptation
或许我们可以独处一下 就你和我 在这暧昧的氛围之下
Sipping on your lips, hanging on by thread, baby
试探性地轻吻下你的唇 然后缠绵在舌尖 辗转厮磨 越陷越深
Late night watching television
我们也可以深夜一起窝在沙发看剧依偎
But how we get in this position?
但这么快就到这一步是否合适
It's way too soon, I know this isn't love
也许真的进展太快 还不能把这一切叫作爱
But I need to tell you something
但我真的很想对你说
I really really really really really really like you
我真的 真的 真的 真的好喜欢你
And I want you, do you want me, do you want me, too?
真的好想就这样拥着你占有你 你是否有和我一样的心情
I really really really really really really like you
我是真的 真的 真的 真的好喜欢你
And I want you, do you want me, do you want me, too?
也真的好像就这样将你占据 你是否也会有和我一样的心情
Oh, did I say too much?
噢 我是不是有点多话了
I'm so in my head
但我心里确实是这样想的
When we're out of touch
尤其当我们没在联络的时候
I really really really really really really like you
我才真的明白 我是真的真的很喜欢你
And I want you, do you want me, do you want me, too?
也真的好想得到你拥有你占有你 告诉我你和我也是一样的心情
Who gave you eyes like that?
是谁赋予你如此美丽动人的双眸
Said you could keep them
让你用它将我心魂都勾走
I don't know how to act
我不知该如何故作镇定
The way I should be leaving
也许我不该看着你的眼睛
I'm running out of time
但再不说点什么就再没机会了吧
Going out of my mind
就抛开所有理智和顾虑
I need to tell you something
对你说出我的真心话吧
Yeah, I need to tell you something
对 我真的想对你说
Yeah I really really really really really really like you
我真的 真的 真的 真的好喜欢你
And I want you, do you want me, do you want me, too?
真的好想就这样拥着你占有你 你是否有和我一样的心情
I really really really really really really like you
我是真的 真的 真的 真的好喜欢你
And I want you, do you want me, do you want me, too?
也真的好像就这样将你占据 你是否也会有和我一样的心情
Oh, did I say too much?
噢 我是不是有点多话了
I'm so in my head
但我心里确实是这样想的
When we're out of touch
尤其当我们没在联络的时候
I really really really really really really like you
我才真的明白 我是真的真的很喜欢你
And I want you, do you want me, do you want me, too?
也真的好想得到你拥有你占有你 告诉我你和我也是一样的心情
I really really really really really really like you
我真的 真的 真的 真的好喜欢你
And I want you, do you want me, do you want me, too?
真的好想就这样拥着你占有你 你是否也会有和我一样的心情
I really really really really really really like you
我是真的 真的好喜欢你 不想失去你
And I want you, do you want me, do you want me, too?
也真的好想得到你拥有你占有你 告诉我你和我也有一样的心情
收起
