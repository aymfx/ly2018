---
title: javascript流程语句以及运算符，BOW操作图，以及学习路线图
date: 2016-08-03
tags: javascript
---

# 前言
	由于比较简单，就直接附上两张图就好，方便以后查询
## 流程语句图
![这里写图片描述](http://img.blog.csdn.net/20170205155634553?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcXFfMjkxMDQ5OTk=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

## 运算符图
![这里写图片描述](http://img.blog.csdn.net/20170205155719631?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcXFfMjkxMDQ5OTk=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

![这里写图片描述](http://img.blog.csdn.net/20170205181058043?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcXFfMjkxMDQ5OTk=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)



## 最后附上一张完整的学习路线，加油
![这里写图片描述](http://img.blog.csdn.net/20170205155804210?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvcXFfMjkxMDQ5OTk=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)
