---
layout: ‘
title: node 常用的包
date: 2017-08-09 17:07:11
tags: node
---

# cnpm i -g supervisor

>  这个命令不用自己重新运行修改后的代码，它会监视你对代码的改动,当代码被改动时，运行的脚本会被终止，然后重新启动

# superagent

> 用于抓取整个网页

# cheerio

> 类似jquery

# supertest

> 用于请求数据

# nodemon

> 热启动 自动检测代码




