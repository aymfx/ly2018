THIS REPO IS NOT SUPPORTED ANYMORE!
DON'T NEED CREATE ISSUE HERE!
NEXT MOVED HERE: https://github.com/theme-next/hexo-theme-next

NexT is rebased into organization repo https://github.com/theme-next
If you want new feature, fix, or support, create new issue in NexT v6.x repo (desirable in English).

There is instructions
on English: https://github.com/theme-next/hexo-theme-next/blob/master/docs/UPDATE-FROM-5.1.X.md
or Chinese: https://github.com/theme-next/hexo-theme-next/blob/master/docs/zh-CN/UPDATE-FROM-5.1.X.md
how to update from v5.1.x to v 6.x

You also may read this for details: https://github.com/iissnan/hexo-theme-next/issues/2061

***

该工程已不再提供任何支持与维护！
请大家不要再在这里创建issue了！
NexT主题仓库已移动到此处: https://github.com/theme-next/hexo-theme-next

NexT已经rebase到theme-next组织(https://github.com/theme-next) 的repo中.
如果你想要求新的特性，bug修复或其他支持，请在新的v6.x的仓库下创建新issue（最好用英文，谢谢）


英文文档: (https://github.com/theme-next/hexo-theme-next/blob/master/docs/UPDATE-FROM-5.1.X.md)
或中文文档: (https://github.com/theme-next/hexo-theme-next/blob/master/docs/zh-CN/UPDATE-FROM-5.1.X.md)
如何从 v5.1.x 更新到 v 6.x

相关细节参考这里: https://github.com/iissnan/hexo-theme-next/issues/2061
